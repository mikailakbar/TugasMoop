package Soal2;

public class MyClassFibonacci implements Runnable{

	@Override
	public void run() {
		try {
			Thread.sleep(120000);
			int n = 20, number1 = 0, number2 = 1;
			System.out.println(n + " Angka Fibonacci: ");

			for (int i = 1; i <= n; ++i) {
				System.out.print(number1 + " , ");
				int sum = number1 + number2;
				number1 = number2;
				number2 = sum;
			}
		} catch (InterruptedException e) {
	
		}
	}

}
