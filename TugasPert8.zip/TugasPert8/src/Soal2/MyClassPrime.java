package Soal2;

public class MyClassPrime implements Runnable {

	@Override
	public void run() {
		System.out.println("Please wait 1 minutes for first 10 prime numbers");
		try {
			Thread.sleep(60000);
			int n = 30;
	        System.out.println("The first 10 prime numbers are : ");
	        for(int i=2; i<n; i++) {
	            boolean isPrima = true;
	            
	            for (int j = 2; j < i; j++) {
	                if(i%j==0){
	                    isPrima = false;
	                    break;
	                    
	                }
	            }
	            if(isPrima==true){
	                System.out.print(i+" , ");
	            }
	        }
	        System.out.println(" ");
	        System.out.println("Please wait 1 minutes for 20 first fibonnaci numbers");
		} catch (InterruptedException e) {

		}
	}

}
