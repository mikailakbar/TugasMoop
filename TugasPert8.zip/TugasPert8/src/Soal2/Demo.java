package Soal2;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClassPrime myClassPrime = new MyClassPrime();
		Thread thread = new Thread(myClassPrime);
		thread.start();
		
		MyClassFibonacci myClassFibonacci = new MyClassFibonacci();
		Thread thread2 = new Thread(myClassFibonacci);
		thread2.start();
		
		
	}

}
