package Soal1;

public class MyClassFibonacci implements Runnable {
	int number;

	public MyClassFibonacci(int number) {
		this.number = number;
	}

	@Override
	public void run() {
		int n = 20, number1 = 0, number2 = 1;
		System.out.println(n + " Angka Fibonacci: ");

		for (int i = 1; i <= n; ++i) {
			System.out.print(number1 + " ");
			int sum = number1 + number2;
			number1 = number2;
			number2 = sum;

			if (sum != number1 + number2 && number1 != number2 && number2 != sum) {
				System.out.println("Not Fibonnaci");
			} else {
				System.out.println("Is Fibonnaci");
			}
		}
		System.out.println("If the number you already input isn't here, so that's not Fibbonaci");
	}

}
