package Soal1;

public class MyClassGanjilGenap implements Runnable {
	
	int number;
	
	public MyClassGanjilGenap(int number) {
		System.out.println("Please wait 30 seconds for odd/even result");
		this.number = number;
	}


	@Override
	public void run() {
		try {
			Thread.sleep(30000);
			if(number %2 == 1){
				System.out.println("Odd Number");
			}
			else{
				System.out.println("Even Number");
			}
		} catch (InterruptedException e) {
		}
	}
	


}
