package Soal1;

import java.util.Scanner;

public class Demo {
	
	public static void main(String[] args){
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		int number;
		
		System.out.println("Please input the integer : ");
		number = scan.nextInt();scan.nextLine();
		MyClassGanjilGenap myClassGanjilGenap = new MyClassGanjilGenap(number);
		Thread thread = new Thread(myClassGanjilGenap);
		thread.start();

		MyClassFibonacci myClassFibonacci = new MyClassFibonacci(number);
		Thread thread2 = new Thread(myClassFibonacci);
		thread2.start();

	}

}
